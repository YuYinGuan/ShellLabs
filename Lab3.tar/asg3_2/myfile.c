/*
*Programming Assignment 3 design document
*Group: Jing Zhou, Che-An Wu, Lu Liu, Yu Yin Guan
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "myfile.h"

disk_t disk;
int superblock = 0;
int bitmap_block = 0;
int root_block =0 ; 
int data_block = 0;
int bitmap_size = 0;
unsigned char *g_buffer = NULL;

void create_superblock(disk_t disk){
  int mapsize;
  int disk_size;
  int offset;
	
  superblock = _SUPER_BLOCK_NUM;

  // first decide the size of bitmap
  mapsize = disk->size / 8;	// bitmap size in bytes
  bitmap_size = 1+ (mapsize-1) / disk->block_size; // bitmap size in blocks	
  // write disk size to buffer 
  disk_size = disk->size;
  offset = 0;
  memcpy(&g_buffer[offset], &disk_size, 4);
  // write bitmap block to buffer
  bitmap_block = 1;
  offset += 4;
  memcpy(&g_buffer[offset], &bitmap_block, 4);
  // write root block to buffer
  root_block = bitmap_block+bitmap_size;
  offset += 4;
  memcpy(&g_buffer[offset], &root_block, 4);
  // write data block to buffer
  data_block = 1+root_block;
  offset += 4;
  memcpy(&g_buffer[offset], &data_block, 4);

  // add bit map size to superblock
  offset += 4;
  memcpy(&g_buffer[offset], &bitmap_size, 4);
  // write superblock content to block 0
  writeblock(disk, superblock, g_buffer); 
	
  printf("Superblock created at block %d\n", superblock);
}

void updatebitmap(unsigned char *bitmap, int block, int flag){
  int index, offset;
  unsigned char mask;

  index = block/8;
  offset = block%8;
    
  mask = 1 << offset;

  if (flag)
    bitmap[index] |= mask; // set allocated block;
  else
    bitmap[index] &= ~(mask); // set free block
		
}

void create_bitmap(disk_t disk){
  char *bitmap;
  int i;
  // allocate bitmap
  bitmap = malloc(bitmap_size*disk->size);
  // initialize bitmap
  memset(bitmap, 0, bitmap_size*disk->size);
  //for (i=0; i<bitmap_size; i++)
  //  updatebitmap(bitmap, i, 0);

  // update superblock, bitmap blocks, root blocks
  updatebitmap(bitmap, superblock, 1);
  for (i = bitmap_block; i< bitmap_size; i++)
    updatebitmap(bitmap, i, 1);
  updatebitmap(bitmap, root_block, 1); 

  // write back to disk
  for (i=0; i<bitmap_size; i++){
    memcpy(g_buffer, &(bitmap[i*disk->block_size]), disk->block_size);
    writeblock(disk, bitmap_block+i, g_buffer);
  }

  // free bitmap
  free(bitmap);
  printf("Free block map created at block %d to block %d\n", bitmap_block, bitmap_block+bitmap_size-1);
}

void cleanblock(int block){
  int i;
  unsigned char *databuf;
  databuf = malloc(disk->block_size);

  for (i=0; i<disk->block_size; i++)
    databuf[i] = '\0';    // delete data
  // write back to disk
  writeblock(disk, block, databuf);
  free(databuf);
}

void create_root(disk_t disk){
  // empty root block
  cleanblock(root_block);

  // set first 4 bytes for total numbers of files
  // update it when writing directory(creating files)
  int i = 0;
  int offset = 0;
  unsigned char * fnum = malloc(disk->block_size);
  memcpy(&fnum[offset], &i, 4);
  writeblock(disk, root_block, fnum);
  free(fnum);

  printf("Root directory created at block %d\n", root_block);
}

void clean_data(disk_t disk){
  int i;
  // clean data blocks
  for (i= data_block; i<disk->size; i++)
    cleanblock(i);

  printf("Data block formated starting at block %d\n", data_block);
}


// read the superblock information
int read_superblock(disk_t disk, pSuperBlock pSb)
{
  int i;
  unsigned char * databuf = malloc(disk->block_size);

  if (databuf == NULL){
    printf("read superblock: allocate mem failed\n");
    exit(-1);
  }
    
  // read out the super block information
  i = readblock(disk, _SUPER_BLOCK_NUM, databuf);
  if (i != 0) {
    free(databuf);
    printf("read superblock : failed\n");
    exit(-1);
  }

  // copy over to super block struct
  memcpy((void*)pSb, databuf, sizeof(superblock_t));

  // free the data
  free(databuf);
  return 0;
}

//check if the block is empty. 1 means allocated; 0 means empty
int check_block(unsigned char * bitmap, int block){
  int index, offset;
  unsigned char mask;
  int res;

  index = block/8;
  offset = block%8;
    
  mask = 1 << offset;


  if ((bitmap[index] & mask) > 0) res = 1;
  else res = 0;

  //printf("res = %d\n", res);
  return res;
}

// allocate one block, -1 means no available block. otherwise, 
// block #
int allocate_block(unsigned char *bitmap, int data_block_num, int disk_size)
{
  //find one empty block for inode
  int i = data_block_num; //search from data block
  while (check_block(bitmap, i) == 1) ++i;

  // no block available
  if (i == disk_size){
    printf("allocate_block: no available block \n");
    return -1;
  }
    
  // mark the inode block as 1
  updatebitmap(bitmap, i, 1);

  return i;
}

// read the bit map to memory 
void read_bitmap(unsigned char * bitmap, int b_block_num, 
		 int b_map_size, disk_t disk){
  int i = 0, offset = 0;
  for (i = 0; i < b_map_size; ++i){ //get completed bitmap
    readblock(disk, i + b_block_num, bitmap + offset);
    offset += disk->block_size;
  }
}

// update the bit map in block
void write_bitmap(unsigned char * bitmap, int b_block_num, 
		  int b_map_size, disk_t disk){
  int i = 0, offset = 0;
  for (i = 0; i < b_map_size; ++i){ //get completed bitmap
    writeblock(disk, i + b_block_num, bitmap + offset);
    offset += disk->block_size;
  }
}


// read the directory, currently only support root directory
// inode parameter is not used
int readdir(disk_t disk, int inode, unsigned char * databuf){
    
  superblock_t sb;

  // read out the super block information
  read_superblock(disk, &sb);

  int i = readblock(disk, sb.root_block_num, databuf);
  if (i != 0) {
    printf("readdir: failed\n");
    exit(-1);
  }
  return 0;
}

//write dirctory = create a file
int writedir(disk_t disk, unsigned char * filename){
  superblock_t sb;
  inode_t inode_i;
  int i, j;
    
  // read out super block information
  read_superblock(disk, &sb);

  //get bitmap info
  unsigned char * buffer = malloc(disk->block_size);
  unsigned char * bitmap = malloc(disk->block_size * sb.bitmap_size);
    
  // read out the bitmap
  read_bitmap(bitmap, sb.bitmap_block_num, sb.bitmap_size, disk);
    
  // alocate one block
  i = allocate_block(bitmap, sb.data_block_num, sb.disk_size);
  if (i == -1){
    printf("no available block\n");
    exit(-1);
  }

#if 0
  for (i = 1; i < sb.root_block_num; ++i){ //get completed bitmap
    int offset = (i - 1) * disk->block_size;
    readblock(disk, i, buffer);
    memcpy(&bitmap[offset], buffer, disk->block_size);
  }

  //find one empty block for inode
  i = sb.data_block_num; //search from data block
  while (check_block(bitmap, i) == 1) ++i;

  printf("data_block num = %d blk = %d \n", sb.data_block_num, i);
  
  // no block available
  if (i == sb.disk_size){
    printf("no available block \n");
    exit(-1);
  }
#endif
    
  // mark the inode block as 1
  updatebitmap(bitmap, i, 1);
  
  unsigned char * newbuf = malloc(disk->block_size);
  unsigned char * origin = malloc(disk->block_size);
  readdir(disk, sb.root_block_num, origin);
  
  // copy the original
  memcpy(newbuf, origin, disk->block_size);
  
  //update file number
  int fnum; 
  memcpy((char *)(&fnum), origin, 4);
  ++fnum;
  memcpy(newbuf, &fnum, 4);
  
  int offset = sizeof(fnum) + (fnum - 1) * 8;
  //append filename (4 bytes) to buffer
  memcpy(&newbuf[offset], filename, 4);

  //append inode block (4 bytes) to buffer
  offset += 4;
  memcpy(&newbuf[offset], &i, 4);


#if 0 
  printf("sb.r_num = %d, d_b_num = %d, bitmap_num = %d \n",
	 sb.root_block_num,sb.data_block_num,sb.bitmap_block_num);
#endif 
  // update the root directory
  writeblock(disk, sb.root_block_num, newbuf);

  // alocate one block
  j = allocate_block(bitmap, sb.data_block_num, sb.disk_size);
  if (j == -1){
    printf("no available block\n");
    exit(-1);
  }

#if 0
  //find one empty block for data
  j = sb.data_block_num; //search from data block
  while (check_block(bitmap, j) == 1) ++j;

  // no block available
  if (j == sb.disk_size){
    printf("no available block \n");
    exit(-1);
  }
#endif // if 0

  // update the bit map
  updatebitmap(bitmap, j, 1);
    
  // write bit map to disk
  write_bitmap(bitmap, sb.bitmap_block_num, sb.bitmap_size, disk);

  // update the inode block
  memset((char *)(&inode_i), 0, sizeof(inode_t));
  inode_i.file_b_size = 1;
  inode_i.blocks[0] = j;
  memset(buffer, 0, disk->block_size);
  memcpy(buffer, (char *)(&inode_i), sizeof(inode_t));
    
  // write the inode to disk
  writeblock(disk, i,  buffer);

  free(origin);
  free(newbuf);
  free(bitmap);
  free(buffer);

  return 1;
}

int check_inode(disk_t disk, unsigned char * filename){
  int inode;
  //get root directory information
  unsigned char * root = malloc(disk->block_size);
  readdir(disk, 0, root);

  //search file in directory
  int fnum;
  memcpy((char *)(&fnum), root, 4);//get total file number

  int offset = 4;
  unsigned char file_list[5]; 
  file_list[4] ='\0';

  int i = 0;// to count files
  int k =0;
    
  while (i < fnum){ //search
    memcpy(file_list, &root[offset], 4); //get filename from root
#if 0   
    for(k = 0; k < 4; k++){
      printf("f_list = %c\n", file_list[k]);
    }
    printf("filename = %s\n", filename);
#endif // if 0
    if (strcmp(file_list, filename) == 0){
      memcpy((char *)(&inode), &root[offset + 4], 4);
      goto END;
    } 
    offset += 8;
    ++i;
  }
  if (i == fnum){
    printf("file %s does not exist\n", filename);
    inode = -1;
    goto END;
    }
  
END:
  free(root);
  return inode;
    
}

// read the file content, the return value is the length of the databuf
int readfile(disk_t disk, unsigned char * filename, char * databuf, int len){
  //get inode block information
  int i = check_inode(disk, filename);
  if (i == -1) return -1;
  unsigned char * inode_info = malloc(disk->block_size);
    
  readblock(disk, i, inode_info);

  //get file block information
  inode_t it;
  memcpy((void *)(&it), inode_info, sizeof(inode_t));
    
  // get the actual length
  if (len > it.file_size){
    len = it.file_size;
  }
    
  // allocate buffer 
  int blk_num = (len + disk->block_size - 1)/disk->block_size;
  unsigned char * dbuf = malloc(disk->block_size * blk_num);
 
  int j;

  // write the data buf
  for(j = 0; j < blk_num; j++){
    readblock(disk,  it.blocks[j], dbuf + j * disk->block_size);
  }

  // copy the buffer to output buffer
  memcpy(databuf, dbuf, len);

  free(dbuf);
  free(inode_info);
  return len;
}


//overwrite the data block
//same as readfile except for using writeblock in the end
int writefile(disk_t disk, unsigned char * filename, char * databuf/*, int len*/){
   
  // allocate temp buffer for input data
  int j = 0;
  int len = strlen(databuf);
  int blk_num = (len + disk->block_size - 1)/disk->block_size;
  unsigned char * dbuf = NULL;
  dbuf = malloc(disk->block_size * blk_num);

  //printf("dbuf = 0x%x, databuf = 0x%x \n", dbuf, databuf);

  if (dbuf == NULL){
    printf("NULL\n");
  }
  memcpy(dbuf, databuf, len+1);
     
  //get inode block information
  int i = check_inode(disk, filename);
  if (i == -1) {
    free(dbuf);
    return -1;
  }
    
  // read out the inode information
  unsigned char * inode_info = malloc(disk->block_size);
  readblock(disk, i, inode_info);
  
  //get file block information
  inode_t it;
  memcpy((void *)(&it), inode_info, sizeof(inode_t));
  
  // write the first data block to disk
  writeblock(disk,  it.blocks[0], dbuf);
  
  // if input data is bigger than 1 block
  if (blk_num > 1){
    superblock_t sb;
    int k;
        
    // read out the super block information
    read_superblock(disk, &sb);

    unsigned char * bitmap = malloc(sb.bitmap_size * disk->block_size);
        
    // read out the bitmap
    read_bitmap(bitmap, sb.bitmap_block_num, sb.bitmap_size, disk);
    
    // update the other blocks if any 
    for(k = 1; k < blk_num; k++){
      // alocate one block
      int j = allocate_block(bitmap, sb.data_block_num, sb.disk_size);
      if (j == -1){
	printf("no available block\n");
	exit(-1);
      }

      // update the bitmap
      updatebitmap(bitmap, j, 1);
            
      // update the inode block info
      it.blocks[k] = j;
           
      // write the block into 
      writeblock(disk,  it.blocks[k], dbuf + k* disk->block_size);
    }

    // update the bitmap to disk
    write_bitmap(bitmap, sb.bitmap_block_num, sb.bitmap_size, disk);
        
    // free bit map
    free(bitmap);
  }

  // update the inode
  it.file_size = len;
  it.file_b_size = blk_num;
  memcpy(inode_info, (void *)(&it), sizeof(inode_t));
  writeblock(disk, i, inode_info);
  
  free(inode_info);
  free(dbuf);
  return len;
}
 



