#include <unistd.h>
#include "myfile.h"
#include <string.h>

#define MAX_BLOCK_NUM 64

void print_file(disk_t disk, char * fname)
{
    int i, len;
    char * databuf;
    
    // max blocks # supported: 64
    databuf = malloc(disk->block_size * MAX_BLOCK_NUM );

    len = readfile(disk, fname, databuf,
            disk->block_size * MAX_BLOCK_NUM);

    for(i = 0; i < len; i++)
    {
        printf("%c", databuf[i]);
    }

    free(databuf);
}

void print_root(disk_t disk)
{
    unsigned char * root = malloc(disk->block_size);
    superblock_t sb;

    // read super block information.
    read_superblock(disk, &sb);
    readdir(disk, sb.root_block_num, root);
    
    int i, j;
    unsigned char filename[5];
    filename[4] = '\0';
    int offset = 0;

    memcpy((char *)(&i), root, 4);
    offset += 4;

    printf("reading root direcotry...\n");
    printf("total %d files\n", i);
    printf("-------------------- \n");
    printf("filename       inode \n");
    //printf("-------------------- \n");
    for (j = 0; j < i; ++j){
        memcpy(filename, &root[offset], 4);
        printf("%s\t\t ", filename);
        offset += 4;

        int m;
        memcpy((char *)(&m), &root[offset],4);
        printf("%d\n", m);
        offset += 4;
    }
    printf("\n");
    printf("-------------------- \n");

    free(root);
}

void copy_file(disk_t disk, char * src_fname, char * dst_fname)
{
  char *disk_name;
  unsigned char *databuf, *databuf2;
  int i, j, bytes_read;

  int fd = open(src_fname, O_RDWR);
  
  // read the source file
  if (fd == -1)
  {
      printf("copy_file failed\n");
      exit(-1);
  }

  // max blocks # supported: 64
  databuf = malloc(disk->block_size * MAX_BLOCK_NUM );
  bytes_read = 0;

  // read the file out
  while((i = read(fd, (void *)databuf + bytes_read, disk->block_size))
          == 512) 
  {
      bytes_read += i;
  }
  bytes_read += i;

  printf("byteread = %d\n", bytes_read);

  // Create and write some files
  writedir(disk, dst_fname);
  //printf("dst fname = %s\n %s", dst_fname, databuf);
  writefile(disk, dst_fname, databuf, bytes_read);

#if 0
  // read some file
  databuf2 = malloc(512);
  int len = readfile(disk, "hw11", databuf2, 400);

  // print out root directory content
  print_file(databuf2, len);

  // Delete some files 
   free(databuf2);
#endif
   free(databuf);
   close(fd);
}

int main(int argc, char *argv[]){
  char *disk_name;
  disk_t disk;
  int i, j;
  //char *file = "tst1";
  char *str ="It works. Cool.";


  // Read the parameters
  if(argc < 2) {
    printf("Usage: testprogram <disk_name>");
    exit(-1);
  }

  disk_name = (char *)argv[1];

  // Open the disk
  disk = opendisk(disk_name);

  // print root directory
  print_root(disk);

  // copy a file from unix system to my file system
  printf("copy file test1 from unix file system to my file system and rename to tst1.\n");
  copy_file(disk, "test1", "tst1");
  printf("\n");

  // print root directory
  print_root(disk);

  // read and print the copied file 
  printf("read file %s\n", "tst1");
  print_file(disk, "tst1");
  printf("\n");
  
  // create another file tst2
  printf("create another file %s.\n", "tst2");
  writedir(disk, "tst2");

  // write something to file
  printf("write to file %s\n", "tst2");
  writefile(disk, "tst2", str);

  // read and print the file
  printf("read file %s\n", "tst2");
  print_file(disk, "tst2");
  printf("\n");

  // print root directory
  print_root(disk);

  free(disk);

  return 0;
}


