/*
*Programming Assignment 3 design document
*Group: Jing Zhou, Che-An Wu, Lu Liu, Yu Yin Guan
*/



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "myfile.h"

int main(int argc, char* argv[])
{
	char *disk_name;
	//super_t super;

	// Read parameters
	if (argc !=2){
		printf("Usage: format <disk_name>\n");
		exit(-1);
	}

	disk_name = (char *)argv[1];
	
	// open disk
	disk = opendisk(disk_name);
	printf("formating %s...\n", disk_name);

	// allocate buffer
	g_buffer = malloc(disk->block_size);

	// format superblock
	create_superblock(disk);

	// format bitmap
	create_bitmap(disk);
	
	// format root
	create_root(disk);

	// format data
	clean_data(disk);
	
	// free buffer
	free(g_buffer);
	printf("foramting done\n");
	return 0;
}
