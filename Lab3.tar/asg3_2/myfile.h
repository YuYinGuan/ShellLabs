#ifndef _UTILITY_H
#define _UTILITY_H

#include "mydisk.h"

#define _SUPER_BLOCK_NUM    0

typedef struct _inode_t
{
    int file_size;      // file size in byte
    int file_b_size;    // file size in block
    int blocks[16];     // the array to store the block num

} inode_t, pinode_t;

// data structure for superblock
typedef struct _superblock_t
{
    int disk_size;
    int bitmap_block_num;
    int root_block_num;
    int data_block_num;
    int bitmap_size;
} superblock_t, *pSuperBlock;

extern disk_t disk;
extern int superblock, bitmap_block, root_block, data_block;
extern int bitmap_size;
extern unsigned char *g_buffer;

void create_superblock(disk_t);
void create_bitmap(disk_t);
void create_root(disk_t);
void clean_data(disk_t);
void cleanblock(int);
void updatebitmap(unsigned char *, int, int);
int check_block(unsigned char * , int );

#endif // utility_h
