/*
 *  CMPS111 assignment 1, Spring 2013
 *  A simple shell program that handles directory change, output/input redirection,
 *  pipeline and background process.
 *
 *  Created by : Lu Liu, Yu Yin Guan, Jing Zhou, Che-An Wu
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <stdbool.h>
#include <signal.h>

#define NORMAL 			0
#define PIPELINE 		1
#define OUTPUT_REDIRECTION 	2
#define INPUT_REDIRECTION 	3
#define BACKGROUND 		4

#define SIZE			10

extern char **get_line();
void change_directory(char**);
int get_argc(char**);
int get_arguments(char***, int*);
int set_mode(char*[], int, char**[], int[], int*, char*);
void execute(char**[], int[], int);
void set_redirection_env(int, char*);
void signal_handler(int);

int main(){
	char **argv;
	char **args_array[SIZE];
	int argc, m_size;
	int mode[SIZE];
	char err_msg;
	
	argv = malloc(1000);	/* allocate memory to store arguments */
	
	sigset_t ss;
	
	sigset(SIGCHLD, signal_handler);		/* check signal for SIGCHLD */
		
	while(1){      /* start shell */
		
	  	sigemptyset (&ss);			/*empty mask signals in ss*/ 
		sigaddset (&ss, SIGCHLD);		/*add SIGCHLD to mask*/
		
		/*blocks SIGCHLD so it does not conflict with get_line signal*/
		sigprocmask (SIG_BLOCK, & ss, NULL);	
		
		/* get arguments */
		if (!get_arguments(&argv, &argc))
			continue;
			
		/*unblock the SIGCHLD signal after now that get_line finished*/
		sigprocmask (SIG_UNBLOCK, & ss, NULL);	
		
		/* handle exit */
		if (strcmp(argv[0], "exit")==0){
   	 		printf("leaving shell...\n");
			free(argv);		/* deallocate memory before exit shell */
	    		exit(0);
   		}
   		
   		/* handle cd */
    		if (strcmp(argv[0], "cd") == 0){	
    			change_directory(argv);		
			continue;	
		} 
	  				  	  
		/* set command mode */  
		if (!set_mode(argv, argc, args_array, mode, &m_size, &err_msg)){
			printf("syntax error: `%c' unexpected\n", err_msg);
			continue;
		}
		
		/* execute command */
		execute(args_array, mode, m_size);		
	}
	
	return 0;
}

void signal_handler(int signum) {			
	int status;			/* intialize status pointer */
	
	waitpid(-1, &status, WNOHANG);		/*reaps the zombie process if there  is one*/
}

int get_argc(char** args){
	int i = 0;
	while (args[i]!= NULL)
    	i++;
	
	return i;
}

void change_directory(char** args){
	if(args[1] == NULL){	
		chdir(getenv("HOME"));	/* go to home directory if no argument */
	} else {				
		if (chdir(args[1]) < 0)	/* go to argument directory if it's valid */
			printf("no such directory....\n");		
	}
}

int get_arguments(char*** args, int* arg_count){
	char** args2;
	int count, i;
	*arg_count = count = 0;
	
	char curDir[100];
	getcwd(curDir, 100);
	
	printf("%s@%s $ ", getlogin(), curDir);		/* print prompt for user input */
	/* accept use input */
	args2 = get_line();	
	/* get number of args */
	if (!(count = get_argc(args2)))
		return 0;
	
	/* copy args */ 
	for (i =0; i<= count; i++)
		(*args)[i] = args2[i];
		 
	/* loop if last arg is pipe */
	while (*(*args)[count - 1] == '|'){
		do{
			printf("> ");    		
			args2 = get_line();		/* get new args */
		} while (args2[0] == NULL);
    			
		/* append arguments */ 
		i = 0;   
		while (args2[i] != NULL)
			(*args)[count++] = args2[i++];
    		
		(*args)[count] = NULL;
	}
    
	*arg_count = count;
	
	return 1;
}

int set_mode(char* args[], int args_size, char** args_array[], int mode[], int *m_size, char *msg){
	int i=1, n; 
		
	/* initialize mode and args_array arrays */
	for (n = 0; n < SIZE; n++){
		mode[n] = -1;
		args_array[n] = NULL;
	}
	/* set first element */
	mode[0] = NORMAL;
	args_array[0]=args;
	
	/* check for redirection, pipeline, background process */
	for (n=0; n < args_size; n++){
		if (*args[n] == '|' || *args[n] == '>' || *args[n] == '<' || *args[n] == '&' ){ /* if found */
			if (args_size == 1){
				*msg = *args[n];
				return 0;
			}
			if (n == 0 && (*args[n] == '|' || *args[n] == '&')){ /* '|' and '&' can't be first */
			  	*msg = *args[n]; 
			  	return 0; 
			} 
			if (n == args_size - 1 && (*args[n] == '>' || *args[n] == '<')){
				*msg = *args[n];
				return 0;
			} 

			/* set mode */
			switch(*args[n]){
				case '|':					
					mode[i] = PIPELINE;
					break;
				case '>':
					mode[i] = OUTPUT_REDIRECTION;
					break;
				case '<':
					mode[i] = INPUT_REDIRECTION;
					break;
				case '&':
					mode[i] = BACKGROUND;
					break;
				default:
					break;
			}
			
			/* set end of command */
			args[n] = '\0';
			args_array[i++] = &args[n+1];
			
		} 
		
	} 
	
    /* set number of modes need to handle */ 
	*m_size = i;    
     
	return 1;
}


void execute(char** args[], int mode[], int m_size){
	int fd[2];
	pid_t pid, pid2;
	int i, p_index;
	
	/* create new process */
	if ((pid = fork())== -1){	/* return if error */
		printf("error creating process\n");
		return;
	} else if (pid == 0){   /* child process to execute command */    
    		i = 0;
    		/* set redirection environment before pipeline if there is any */
    		while (++i < m_size && mode[i] != PIPELINE) 
    			set_redirection_env(mode[i], *args[i]);
    		
    		/* create pipeline if pipe exists */
    		if (i < m_size && mode[i] == PIPELINE){
    			p_index = i;
    			/* create pipe */	
			if (pipe(fd) == -1){
				printf("error on pipe\n");
				return;
			}	
    	   		/* create new process */
    			if ((pid2=fork()) == -1){
    				printf("error on fork\n");
    				return;
    			} else if (pid2==0){	/* child process for post pipe command */
    				close(fd[1]);		/* close output */
    				dup2(fd[0],fileno(stdin));	/* redirect input from pipe */
    			
    				/* set redirection environment after pipeline if there is any */
    				while (++i < m_size)
    					set_redirection_env(mode[i], *args[i]);    				

    				/* execute post pipe command */
    				if (execvp(*args[p_index], args[p_index])<0){
    					printf("command not found: %s\n", *args[p_index]);
    					exit(1);
    				}
    			
    			} else {	/* parent process for pre-pipeline command */
    				close(fd[0]);	/* close input */
    				dup2(fd[1],fileno(stdout));	/* redirect output to pipe */
    			}
    								
		}
		
    		/* execute command, pre pipe command is executed here */
    		if (*args[0]!=NULL)	
    			if (execvp(*args[0], args[0])< 0)
    				printf("%s: command not found\n", *args[0]);
    	
    		exit(1); /* exit process if *args[0] = NULL */
    	} else	/* parent process for shell */
    		if (mode[m_size-1] != BACKGROUND){	/* block when child process is foreground */
    			waitpid(-1, NULL, 0);
    			usleep(5000);
    		}

}

void set_redirection_env(int mode, char* arg){
	switch(mode){
    	case OUTPUT_REDIRECTION: /* redirection output */
    		freopen(arg, "w", stdout);    	
    		break;
    	case INPUT_REDIRECTION: /* redirection input */
    		freopen(arg, "r", stdin);
			break;	
    	default:
    		break;
	}
}
