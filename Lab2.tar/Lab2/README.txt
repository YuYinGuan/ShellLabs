## Created By: Yu Yin Guan, Lu Liu, Che-An Wu, Jing Zhou

This directory contains source code for mythread.c
Testing info
============================
This program is tested on Minix and Ubuntu and Unix. 


Features of mythread
-------------------------
1. Handle multiple threads
2. Preemptive lottery scheduler with a time quantum 
3. Support signal handler for alarm
4. Use alarm_wakeup() to swap a thread in process 
5. Exit when all threads are finished
--------------------------


To run start mythread first compile by gcc and create object file by running:

	gcc -c mythread.c
        gcc -o mythread mythread.o 

Then run:

	./mythread

