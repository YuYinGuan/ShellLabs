//
//  threads.c
//  
//
//  Created by Scott Brandt on 5/6/13.
//
//

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/time.h>
#include <ucontext.h>

#define INTERVAL 500000
#define _XOPEN_SOURCE
#define THREAD_MAX 100    //********max number of threads

static ucontext_t ctx[THREAD_MAX];    //********set up as a large number
static void test_thread(void);
static int thread = 0;
struct itimerval tout_val;
void thread_exit(int);
void alarm_wakeup ();

// var for the scheduler
static int running_thread[THREAD_MAX];
static int num_thread;

int main(void) {
	int n;
    srand(time(0));
    printf("Main starting\n");
    printf("Main calling thread_create\n");
    
    num_thread = 1;
    running_thread[thread] = 1;

    //********* create 9 threads (main is thread 0)
    for (thread = 1; thread < THREAD_MAX; ++thread){
        thread_create(&test_thread);
        running_thread[thread] = 1;
        num_thread++;
    }
	
    thread = 0;  //******* let it start from main, then 1, 2, 3, ...roundrobin 

    printf("Main returned from thread_create\n");

    //****** set timer for "INTERVAL" seconds 
    tout_val.it_interval.tv_usec = INTERVAL;
    tout_val.it_interval.tv_sec = 0;
    tout_val.it_value.tv_usec = INTERVAL;
    tout_val.it_value.tv_sec = 0;
    setitimer(ITIMER_VIRTUAL, &tout_val, 0);	// start virtual timer
    
	signal(SIGVTALRM, alarm_wakeup);	// set signal handler
	
    while (num_thread != 1);	// loop until all other threads end
	
	printf("main ends\n");
    exit(0);
}

// signal handler
void alarm_wakeup()
{
    int old_thread = thread;
    thread = next_thread();

    printf("thread %d used out its quantum\n",old_thread);
    printf("switch to thread %d\n", thread);
    printf("thread %d starts running\n", thread);
    printf("\n");
    swapcontext(&ctx[old_thread], &ctx[thread]);
}

// scheduler
int next_thread(){
	int newthread;
	do
	 	newthread = rand()%THREAD_MAX;
	while(!running_thread[newthread]);
	return newthread;
}

// dummy function to run for each thread
static void test_thread(void) {
	int i = (rand()%100+1)*1000000;
    while(i--) {
        // do nothing 
    }
    thread_exit(0);
}

// yield to another thread when one thread ends
int thread_yield() {
	int old_thread = thread;
	num_thread--;
	// update running_thread table
	running_thread[old_thread] = 0;
	// reset timer
	tout_val.it_value.tv_usec = INTERVAL;
	// get next thread
	thread = next_thread();
	
    printf("Thread %d yielding to thread %d\n", old_thread, thread);
    //printf("Thread %d calling swapcontext\n", old_thread);
    printf("thread %d starts running\n", thread);
    printf("\n");

    // This will stop us from running and restart the other thread
    swapcontext(&ctx[old_thread], &ctx[thread]);
}

// create a new thread
int thread_create(int (*thread_function)(void)) {
    int newthread =  thread;
    printf("Thread %d in thread_create\n", thread);
    printf("Thread %d calling getcontext and makecontext\n", thread);

    getcontext(&ctx[newthread]);
    ctx[newthread].uc_stack.ss_sp = malloc(8192);
    ctx[newthread].uc_stack.ss_size = 8192;
    ctx[newthread].uc_link = NULL;
    makecontext(&ctx[newthread], test_thread, 0);

    printf("Thread %d done with thread_create\n", thread);
}

// thread ends
void thread_exit(int status) {
    printf("Thread %d exiting\n", thread);
	thread_yield();
}
